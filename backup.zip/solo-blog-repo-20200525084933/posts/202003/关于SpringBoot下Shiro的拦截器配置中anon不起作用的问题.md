title: 关于SpringBoot下Shiro的拦截器配置中anon不起作用的问题
date: '2020-03-17 09:59:34'
updated: '2020-03-17 10:00:50'
tags: [springboot, shiro, 技术]
permalink: /articles/2020/03/17/1584410373904.html
---
我在配置文件application.yml中的配置和shiroFilter中动态拦截器注入的代码如下图所示，启动后访问 `/login/auth `登录请求接口时，依然是被Shiro拦截的；

![image.png](https://img.hacpai.com/file/2020/03/image-22467426.png)![image.png](https://img.hacpai.com/file/2020/03/image-050c8e75.png)

其实问题就出在shiroFilter的动态拦截注入的代码中；因为shiro的拦截是从上往下依次匹配的，所以在配置中，需要将
`/**`放在最后，然后依次设置需要放行或拦截的资源。所以既然配置文件中的资源已经是正确的配置了，为啥启动后访问还是被拦截了呢？这是因为HashMap是无序的，在启动时，配置文件被加载了，存储到了 `filterRuleMap`中，但是它已经变成无序的了；解决方法就是让 `filterRuleMap`变的有序，修改后的代码如下：

![image.png](https://img.hacpai.com/file/2020/03/image-d2930c9a.png)

好了，重新启动你的服务，然后访问 `/login/auth `接口，现在已经按照你的设定完成了操作；
