title: 在Mac上如何快速查看本机IP地址
date: '2020-03-13 10:10:28'
updated: '2020-03-13 10:10:28'
tags: [MacOS]
permalink: /articles/2020/03/13/1584065428028.html
---
按住 option 键，然后点击 Mac 状态栏中的 WIFI 图标， 在当前连接的 WIFI 下方 会出现 IP 地址等相关信息

![](https://img.hacpai.com/file/2020/03/image-06bbfed9.png "image.png")
