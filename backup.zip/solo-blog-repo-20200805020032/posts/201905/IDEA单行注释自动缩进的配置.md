title: IDEA 单行注释自动缩进的配置
date: '2019-05-23 21:20:09'
updated: '2019-05-23 21:20:09'
tags: [IntelliJIDEA]
permalink: /articles/2019/05/23/1558617608961.html
---
#### 单行注释快捷键
 `ctrl(command)+/` 添加注释
`ctrl(command)+/`取消注释
#### 未设置前，逼死强迫症
![image.png](https://img.hacpai.com/file/2019/05/image-16a44c97.png)
#### 设置后
![image.png](https://img.hacpai.com/file/2019/05/image-dc97bb97.png)
#### 设置
	打开设置界面，依次选择Editor-Code Style-Java，选择Code Generation，取消Line comment at first column和Block comment at first column的选中即可。
![image.png](https://img.hacpai.com/file/2019/05/image-00521059.png)
