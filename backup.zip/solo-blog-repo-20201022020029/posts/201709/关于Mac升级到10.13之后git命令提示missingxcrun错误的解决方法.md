title: 关于Mac升级到10.13之后git命令提示missing xcrun错误的解决方法
date: '2017-09-26 22:10:54'
updated: '2017-09-27 09:01:56'
tags: [Mac, MacOS High Sierra, git]
permalink: /articles/2017/09/26/1506435000252.html
---
今天升级了[MacOS High Sierra 10.13](http://www.tuchief.com/articles/2017/09/26/1506390561810.html)，之后打开我的IDEA，就提示Git错误，具体的错误信息如下
> xcrun: error: invalid active developer path (/Library/Developer/CommandLineTools),
missing xcrun at: /Library/Developer/CommandLineTools/usr/bin/xcrun

#### 解决方法：
只需要在终端下执行如下命令，在弹出的对话框中点击安装，等待安装完成即可！

```
xcode-select --install
```

如下图所示：
![](http://ouco65qeg.bkt.clouddn.com/Jietu20170926-220019.jpg)


