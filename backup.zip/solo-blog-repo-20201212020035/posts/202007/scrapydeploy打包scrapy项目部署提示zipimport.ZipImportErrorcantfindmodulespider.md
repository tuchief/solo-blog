title: scrapy-deploy打包scrapy项目部署，提示 zipimport.ZipImportError:can't find module 'spider'
date: '2020-07-07 14:39:58'
updated: '2020-07-07 14:39:58'
tags: [python]
permalink: /articles/2020/07/07/1594103998350.html
---
#### 原因

打包时的环境用的是python3.7，而部署的环境python版本为3.6，二者的版本不一致，导致的该错误；

#### 解决方法

统一打包和部署的python版本即可解决；
