title: 解决Github无法加载或不显示图片问题
date: '2020-11-05 12:17:17'
updated: '2020-11-05 12:22:02'
tags: [github]
permalink: /articles/2020/11/05/1604549837340.html
---
![6efb9bc5d143article190612githubbodytext.jpg](https://b3logfile.com/file/2020/11/6efb9bc5d143article190612githubbodytext-10decac6.jpg)

修改host文件，不同系统host文件的存放位置不同，以下以Mac系统为例；

* [X]**时间：2020-11-05 确认可用**

#### 一、打开Mac终端并输入

```
`sudo vi /etc/hosts`
```

#### 二、完成密码输入，点击 `i`键，进入Insert模式，然后将以下内容拷贝到文件末尾

```
# GitHub Start 
192.30.253.112    Build software better, together 
192.30.253.119    gist.github.com
151.101.184.133    assets-cdn.github.com
151.101.184.133    raw.githubusercontent.com
151.101.184.133    gist.githubusercontent.com
151.101.184.133    cloud.githubusercontent.com
151.101.184.133    camo.githubusercontent.com
151.101.184.133    avatars0.githubusercontent.com
151.101.184.133    avatars1.githubusercontent.com
151.101.184.133    avatars2.githubusercontent.com
151.101.184.133    avatars3.githubusercontent.com
151.101.184.133    avatars4.githubusercontent.com
151.101.184.133    avatars5.githubusercontent.com
151.101.184.133    avatars6.githubusercontent.com
151.101.184.133    avatars7.githubusercontent.com
151.101.184.133    avatars8.githubusercontent.com

 # GitHub End
```

#### 三、点击 `ESC` 键，然后输入 `:wq` 保存并退出

#### 四、此时再打开或刷新Github的页面，裂开的图片就已经可以正常显示了
