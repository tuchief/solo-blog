title: MacOS High Sierra 10.13 发布
date: '2017-09-26 09:49:31'
updated: '2017-09-27 09:02:06'
tags: [Mac, MacOS High Sierra]
permalink: /articles/2017/09/26/1506390561810.html
---

![](http://ouco65qeg.bkt.clouddn.com/WechatIMG31.jpg)

##### 版本及大小
  2017年09月25日
  MacOS High Sierra 10.13
  大小4.80G
##### 亮点1
  跨设备的通用剪贴板功能；
##### 亮点2
  底层引入更为先进的APFS文件系统，它不仅可以让你的 SSD 磁盘文件的存取速度更快，而且更加节省存储空间，这对于硬盘空间较小的MAC用户来说应该有吸引力吧；📂
##### 亮点3
  更加实用的备忘录；📝

[下载地址](https://itunes.apple.com/cn/app/macos-high-sierra/id1246284741?mt=12)