title: springboot在构造方法中使用@Value获取配置信息为null的原因与解决
date: '2020-06-16 11:35:07'
updated: '2020-06-16 11:36:29'
tags: [springboot, java]
permalink: /articles/2020/06/16/1592278507815.html
---
![everythingmustknowspringbootapplicationscratch12.jpg](https://b3logfile.com/file/2020/06/everythingmustknowspringbootapplicationscratch12-834a8e74.jpg)

之所以获取的值为null，是因为执行顺序的问题，在构造器里面该对象还没有实例化，所以这个注入的对象就为null，执行的顺序是：先执行构造器，然后再注入值

解决方法：`implement  InitializingBean`

接着去实现方法:

```
public void afterPropertiesSet() throws Exception {
}
```

然后把在构造器里要执行的操作都挪到该方法里面去实现即可；
