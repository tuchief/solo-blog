title: 在CodeMirror编辑界面中光标处插入内容
date: '2018-07-22 00:46:07'
updated: '2018-07-22 00:48:44'
tags: [codemirror]
permalink: /articles/2018/07/22/1532191523858.html
---
#### 效果
要实现的效果图如下所示：
![](http://ouco65qeg.bkt.clouddn.com/2018-07-21-test.gif)

#### 官方API：
`**doc.replaceSelection**(replacement: string, ?select: string)`

Replace the selection(s) with the given string. By default, the new selection ends up after the inserted text. The optional `select` argument can be used to change this—passing `"around"` will cause the new text to be selected, passing `"start"` will collapse the selection to the start of the inserted text.

`**doc.replaceSelections**(replacements: array, ?select: string)`

The length of the given array should be the same as the number of active selections. Replaces the content of the selections with the strings in the array. The `select`argument works the same as in [`replaceSelection`](https://codemirror.net/doc/manual.html#replaceSelection).

#### 实现
官方文档好一顿翻，终于特么一句话搞定的！😓
```
myCodeMirror.replaceSelection("插入的内容");
```
🎉