title: 一条命令让您的 macOS 用 Touch ID 授权 sudo
date: '2017-11-30 12:45:20'
updated: '2017-11-30 12:45:20'
tags: [Mac]
permalink: /articles/2017/11/30/1512016920489.html
---
## 前言

经常使用命令行的小伙伴一定对 `sudo` 命令不陌生，它可以以特定用户身份执行特定的命令。很多时候我们也会用它来执行系统管理命令。

但是，每次以非 root 身份执行 `sudo` 时，都必须输入密码。这种操作对于配备 Touch ID 的 MacBook Pro 用户肯定多少有些不爽的。

我也因为这个问题而不爽了好久，如果能够通过刷指纹验证 `sudo`，那该有多爽啊！

前一个星期非常偶然地看到[一篇文章](https://www.imore.com/how-use-sudo-your-mac-touch-id "一篇文章")，介绍了如何使用 Touch ID 来验证 `sudo` 命令。

这篇文章顿时让我激动不已，马上尝试了一下，果然非常爽！好东西不敢独享，于是我把它整理成了一条命令，方便大家使用。

* * *

## 系统环境

由于系统的功能是随着升级而不断变化的，所以不保证长期有效。

*   机型：MacBook Pro 15" 2017
*   系统：macOS 10.13.1

* * *

## 操作方法

打开“终端”，执行以下命令：

```
sudo sed -i ".bak" '2s/^/auth       sufficient     pam_tid.so\'$'\n/g' /etc/pam.d/sudo

```

然后输入您的管理员密码，回车，大功告成了！不用重启哦～

> **命令说明**
>
> *   该命令的作用是把 `/etc/pam.d/sudo` 备份为 `/etc/pam.d/sudo.bak`，然后在 `/etc/pam.d/sudo` 的第二行前面加入 `auth sufficient pam_tid.so` 这个字符串。
>
>
> *   修改该文件的目的是在 `sudo` 程序的认证过程前面插入 Touch ID 验证的模块。感兴趣的小伙伴可以去了解一下 [PAM 架构](http://www.infoq.com/cn/articles/wjl-linux-pluggable-authentication-module "PAM 架构")。
>
>
> *   如果需要恢复原文件，请执行：`sudo mv /etc/pam.d/sudo.bak /etc/pam.d/sudo`。

* * *

## 效果

打开终端，执行 `sudo su`，然后就可以刷指纹啦，爽歪歪～

![](https://ws1.sinaimg.cn/large/006tKfTcgy1fm00d9mf6mj30uu0jatbj.jpg)


下面是 Touch Bar 的提示。

![](https://cdn.sspai.com/2017/11/28/c5906253b86c1b2d5b9268eb975cf4c3.png?imageView2/2/w/1120/q/90/interlace/1/ignore-error/1)

有小伙伴可能会担心远程登录（如 SSH）会不会依然要求刷指纹，我试了一下，是不会的，请放心使用！

来自：[少数派](https://sspai.com/post/42038)