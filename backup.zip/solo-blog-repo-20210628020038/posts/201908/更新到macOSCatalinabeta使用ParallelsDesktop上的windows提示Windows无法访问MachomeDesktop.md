title: 更新到macOS Catalina beta，使用Parallels Desktop上的windows提示 “Windows无法访问\\Mac \ home
  \ Desktop”
date: '2019-08-09 14:43:41'
updated: '2019-08-09 14:43:41'
tags: [macOSCatalina, ParallelsDesktop, windows10, 虚拟机]
permalink: /articles/2019/08/09/1565333021268.html
---
在将系统更新到macOS Catalina beta后，登录在Parallel中创建的Windows系统虚拟后的错误提示如下，原本可以在虚拟机中访问到Mac桌面上的文件，现在都访问不到了，打开虚拟机中的C盘也会弹出改错误提示：
![image.png](https://img.hacpai.com/file/2019/08/image-b4b1405e.png)

解决的方法：
到Parallel的该虚拟机配置中，选择”选型“—”共享“，取消”与Windows共享Mac用户文件夹“选型，取消”与Windows共享云文件夹“，确保勾选了”将Mac宗卷映射到Windows“，配置的结果如下图所示
![image.png](https://img.hacpai.com/file/2019/08/image-2832e0e4.png)
保存后，注销虚拟机后即可解决！