title: 在Dock中显示最近使用的应用程序或文稿
date: '2017-09-02 15:23:48'
updated: '2017-09-02 15:23:48'
tags: [Mac, Dock]
permalink: /articles/2017/09/02/1504336732496.html
---
##### 添加
在终端（command+空格，在Spotlight中输入‘终端’即可找到）中输入👇的命令，回车：

```
defaults write com.apple.dock persistent-others -array-add '{ "tile-data" = {"list-type" = 1; }; "tile-type" = "recents-tile";}' && \killall Dock
```
![](http://ouco65qeg.bkt.clouddn.com/2017-09-02.3.08.46.png)

##### 显示
运行成功后，Dock会重新加载，之后你就可以在Dock中废纸篓旁看到多了一个快捷方式，点击即可显示你最近使用过的10个程序了
![](http://ouco65qeg.bkt.clouddn.com/2017-09-02.12.05.56.png)
##### 自定义
如果你要显示的是最近使用过的文档等其它项目的话，直接在快捷方式上，`右键`，选择你要显示的项目即可
![](http://ouco65qeg.bkt.clouddn.com/2017-09-02.12.06.12.png)

默认显示的是最近的10个项目，如果你需要更改，可以在`系统偏好设置—>通用`中进行修改
![](http://ouco65qeg.bkt.clouddn.com/2017-09-02.11.59.54.png)
##### 删除
如果你不想要显示直接最近使用的项目了，直接控制方式上`右键——>从Dock上移除`即可
![](http://ouco65qeg.bkt.clouddn.com/2017-09-02.3.10.00.png)
