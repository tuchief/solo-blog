title: centos7下安装CDH5.14.4的问题汇总
date: '2020-07-13 22:48:20'
updated: '2020-07-13 22:51:53'
tags: [CDH, cloudera, cloudera-manager]
permalink: /articles/2020/07/13/1594651700341.html
---
### 1. cloudera-manager安装一直卡在了agent的服务安装

因为CM在安装过程中，会检测是否已安装agent，而agent的安装依赖daemons，没安装的情况下，会在线下载安装，这个过程是非常缓慢的，所以提前下好 `cloudera-manager-agent-5.14.4-1.cm5144.p0.3.el7.x86_64.rpm`和 `cloudera-manager-daemons-5.14.4-1.cm5144.p0.3.el7.x86_64.rpm`两个安装包，并上传到各服务器上手动进行安装！

### 2. cloudera-manager安装一直卡在了正在获取安装锁

**解决方法：执行下列命令后重新开始安装**

```
rm -rf /tmp/scm_prepare_node.*
rm -rf /tmp/.scm_prepare_node.lock
```

### 3.  JDBC driver cannot be found. Unable to find the JDBC database jar...

**解决方法：**

将mysql连接驱动放到目录 **`/usr/share/java/mysql-connector-java.jar`** 下即可；

### 4.  Unexpected error. Unable to verify database connection.

查看日志 `/opt/cloudera-manager/cm-5.14.4/log/cloudera-scm-server`发现如下错误信息

![image.png](https://b3logfile.com/file/2020/07/image-fc764a0f.png)

**解决方法：**

`mkdir -p /usr/java`

`ln -s 原jdk安装目录  /usr/java/default`

`vi /etc/profile`

修改JAVA_HOME：`JAVA_HOME=/usr/java/default`

重新加载配置：`source /etc/profile`
