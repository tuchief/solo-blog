title: Element-ui中table使用row-class-name无效的锅
date: '2018-04-20 23:16:58'
updated: '2018-04-20 23:20:58'
tags: [element-ui, 前端]
permalink: /articles/2018/04/20/1524237407008.html
---
一、如果table中使用了stripe（斑马纹），那么row-class-name就会失效！
二、官网给的例子中的代码
```
methods: {
  tableRowClassName({row, rowIndex}) {
    if (rowIndex === 1) {
      return 'warning-row';
    } else if (rowIndex === 3) {
      return 'success-row';
    }
    return '';
  }
},

```
tableRowClassName的参数{row, rowIndex}有点坑啊，打个断点就知道，只需要一个就好了，而且对象层级也是有问题的，后来我改成了
```
tableRowClassName(val) {
    if (val.row.status<0) {
        return 'warning-row';
    }
    return '';
},
```