title: 调整Mac下IDEA的内存来解决卡顿的问题
date: '2018-04-19 14:58:06'
updated: '2018-04-20 23:26:21'
tags: [IDEA, Mac, 工具]
permalink: /articles/2018/04/19/1524119507781.html
---
自从用了IDEA之后，它就完全替代了我原来的eclipse，至于为什么使用它，因为我喜欢，谁让适合自己的才是最好的呢
BUT......
JB全家桶可都是内存大户，用一段时间后（何况还是对从来不需要关电脑的Mac而言），就会感觉到明显卡顿，有时候甚至到了让人想砸电脑的冲动，严重影响效率和工作的积极性；

方法网络上也有很多说明，也有说和git有关系的，而我的方法，适用我，但不一定适用大家的，我就记录下而言，仅此而已，但你可以试试，反正不要钱；

### 系统配置概览
![](http://ouco65qeg.bkt.clouddn.com/2018-04-19-2018-04-19_14-32-23.png)

### 设置
一、IntelliJ IDEA > Preferences > Plugins, 关闭掉不用的Plugins；
![](http://ouco65qeg.bkt.clouddn.com/file/2018/04/7bba296473ad47f7bae1bb132caea85d_image.png)

二、设置软件内存配比
因为我使用的是 JetBrains TOOLBOX (推荐使用) 来管理我JB全家桶，所以我的IDEA路径相对的长长长了点
`/Users/xxx/Library/Application\ Support/JetBrains/Toolbox/apps/IDEA-U/ch-0/181.4668.1`
在 IntelliJ IDEA.app 上，右键，显示包内容，在bin中，打开idea.vmoptions配置文件，以下是我的配置内容
```
-Xms528m
-Xmx2048m
-XX:MaxPermSize=768m
-XX:ReservedCodeCacheSize=768m
-XX:+UseCompressedOops
-Dfile.encoding=UTF-8
-XX:+UseConcMarkSweepGC
-XX:SoftRefLRUPolicyMSPerMB=50
...
```
修改之后保存，重启IDEA即可。

如果你是自己下载安装包安装的IDEA，那么你的安装目录相对简单，就在你的应用程序中，找到IntelliJ IDEA.app，其它操作步骤和上边的一样；