title: 解决 homebrew-core is a shallow clone To `brew update`, first run 错误
date: '2021-02-04 21:49:49'
updated: '2021-02-04 21:54:32'
tags: [brew, MacOS]
permalink: /articles/2021/02/04/1612446589398.html
---
![homebrewlogonew.jpeg](https://b3logfile.com/file/2021/02/homebrewlogonew-a96781b0.jpeg)

今天升级了系统，打算将brew也进行下更新，然后就有了下面的错误提示：

```
➜ brew update
Error: 
  homebrew-core is a shallow clone.
To `brew update`, first run:
  git -C /usr/local/Homebrew/Library/Taps/homebrew/homebrew-core fetch --unshallow
This command may take a few minutes to run due to the large size of the repository.
This restriction has been made on GitHub's request because updating shallow
clones is an extremely expensive operation due to the tree layout and traffic of
Homebrew/homebrew-core and Homebrew/homebrew-cask. We don't do this for you
automatically to avoid repeatedly performing an expensive unshallow operation in
CI systems (which should instead be fixed to not use shallow clones). Sorry for
the inconvenience!


```

其实解决方法也很简单，就是把 `homebrew-core`给删除了就好了：

```
rm -rf /usr/local/Homebrew/Library/Taps/homebrew/homebrew-core;
```

**ps: rm -rf 有风险，操作需谨慎**

![Xnip20210204214213.png](https://b3logfile.com/file/2021/02/Xnip20210204214213-35d01c22.png)
