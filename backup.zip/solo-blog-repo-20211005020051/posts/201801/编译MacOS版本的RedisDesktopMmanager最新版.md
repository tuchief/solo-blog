title: 编译MacOS版本的 RedisDesktopMmanager 最新版
date: '2018-01-08 23:23:05'
updated: '2018-05-25 15:09:12'
tags: [RedisDesktopMmanager, redis, Mac, MacOS High Sierra, 工具]
permalink: /articles/2018/01/08/1515424825749.html
---
![](https://img.hacpai.com/bing/20180325.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

### 下载源码📥

```
git clone --recursive https://github.com/uglide/RedisDesktopManager.git -b 0.9 rdm && cd ./rdm
```
### 环境配置⚒
1. Install XCode with xcode build tools
2. Install Homebrew
3. Build RDM dependencies cd ./src && ./configure
4. Install Qt 5.9
5. Open ./src/rdm.pro in Qt Creator
6. Run build

### 划重点👀💯
1. 直接去下面这个地址下载就可以了

```
http://download.qt.io/official_releases/qt/
```
我下载的是5.10的版本。选择你自己要的版本下载即可，文件略大，耐心等待⌚️

2. 安装QT5.10
![](http://ouco65qeg.bkt.clouddn.com/15154222365829.jpg)
需要用户名密码，如果没有的话，可以选择注册
![](http://ouco65qeg.bkt.clouddn.com/15154223292348.jpg)
我选择去掉Android和iOS（太大了，而且我也不需要）
![](http://ouco65qeg.bkt.clouddn.com/15154223962923.jpg)
接下去就是等待安装完成即可！

3. 启动Qt Creator
![](http://ouco65qeg.bkt.clouddn.com/15154227935164.jpg)

进入刚刚下载的rdm源码目录下，将Info.plist.sample更改为Info.plist
![](http://ouco65qeg.bkt.clouddn.com/15154233895604.jpg)

点击 [下载](https://pan.baidu.com/s/1kU9JS5D) 提取密码：vs3b，将下载下来的文件crashreporter放到下图的对应目录结构下
![](http://ouco65qeg.bkt.clouddn.com/15154235437847.jpg)


打开 src 下的`rdm.pro`, 选择编辑rdm.pro文件，注释掉高亮的行。目的是让其编译能够生产rdm.app文件,默认因为开启了该句所以不生成。
![](http://ouco65qeg.bkt.clouddn.com/15154229573779.jpg)
![](http://ouco65qeg.bkt.clouddn.com/15154241703342.jpg)

将rdm项目添加进来后还需要为qt-creater配置`kits`，就像我们用eclipse或者IntillJ IDEA一样要配置SDK一样的，具体步骤是在qt-creater编辑器的左边栏选择`项目`，在出现的界面选择`Manage Kits...`，然后出现弹出框如下图
![](http://ouco65qeg.bkt.clouddn.com/file/2018/05/082bc2884d63442a8776b2aad5b941ae_image.png)


选择`项目`展开,`构建设置`>`编辑构建配置`， 选择 `release`，等待运行的三角变绿, 点击运行工程
![](http://ouco65qeg.bkt.clouddn.com/15154230672595.jpg)

最后，在编译完成后，会自动运行rdm，并且会在你之前指定的编译目录下（我的 ：/Users/tuchief/workspace/rdm/build-rdm-Desktop_Qt_5_10_0_clang_64bit-Release）生成一个编译完成的rdm文件了

直接将该文件拖入应用程序中即可在日常工作中快速运行了！

👌🏻收工！

不知道是否说明清楚了，如果在此过程中遇到有任何问题，都可以留言告诉我！