title: python pip/conda 升级所有包
date: '2018-07-24 13:41:43'
updated: '2018-07-24 13:41:43'
tags: [python, Anaconda]
permalink: /articles/2018/07/24/1532410813337.html
---
![](https://img.hacpai.com/bing/20180508.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

#### 升级pip命令安装下的包
```
pip install -U distribute

pip freeze --local | grep -v '^\-e' | cut -d = -f 1  | xargs pip install -U
```

#### 升级conda命令安装下的包
```
conda update --all
```