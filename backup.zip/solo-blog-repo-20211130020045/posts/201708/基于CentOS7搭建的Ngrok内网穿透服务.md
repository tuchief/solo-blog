title: 基于CentOS7搭建的Ngrok内网穿透服务
date: '2017-08-14 05:16:32'
updated: '2017-09-24 14:26:33'
tags: [centos7, ngrok, 技术]
permalink: /articles/2017/08/14/1502687731371.html
---
#### 简介
> 与“花生壳”类似。Ngrok 是一个反向代理，通过在公共的端点和本地运行的 Web 服务器之间建立一个安全的通道。ngrok 可捕获和分析所有通道上的流量，便于后期分析和重放。
![](https://camo.githubusercontent.com/f2d698991e6a0411680413ebcc15a6460b8beda3/68747470733a2f2f6e67726f6b2e636f6d2f7374617469632f696d672f6f766572766965772e706e67)

#### 前提条件
* 一个公网IP（搞台云服务器）
* 一个域名（啥级别的都OK）

#### 安装准备

##### 1、安装gcc
`yum install gcc`
##### 2、安装git
`yum install git`
##### 3、安装GO语言环境
* 卸载旧版本的golang

    `yum remove golang`
* 安装最新版本的golang

```
# 下载
wget https://storage.googleapis.com/golang/go1.8.3.linux-amd64.tar.gz

# 解压安装
tar -C /usr/local/ -zxvf go1.8.3.linux-amd64.tar.gz

# 添加环境变量
vi /etc/profile

# 在末尾添加如下内容
##go lang
export GOROOT=/usr/local/go
export PATH=$PATH:$GOROOT/bin
export GOPATH=/root/workspace/go

# 让设置的环境变量生效
source /etc/profile

# 查看安装是否成功
go version
```
##### 4、开始搭建Ngrok服务
###### 4.1、下载ngrok源码
```
cd /usr/local/src
git clone https://github.com/inconshreveable/ngrok.git
```
###### 4.2、生成证书
生成证书时需要之前准备好的一个解析到服务器上的主域名，以下的设置以”ngrok.com”为例，你需要替换成自己的域名

```
cd ngrok

#这里修改成自己的已经正确解析到服务器的域名
export NGROK_DOMAIN="ngrok.com"

# 生成证书
openssl genrsa -out rootCA.key 2048
openssl req -x509 -new -nodes -key rootCA.key -subj "/CN=$NGROK_DOMAIN" -days 5000 -out rootCA.pem
openssl genrsa -out device.key 2048
openssl req -new -key device.key -subj "/CN=$NGROK_DOMAIN" -out device.csr
openssl x509 -req -in device.csr -CA rootCA.pem -CAkey rootCA.key -CAcreateserial -out device.crt -days 5000

# 将新生成的证书，替换掉assets/client/tls下的证书
cp rootCA.pem assets/client/tls/ngrokroot.crt
cp device.crt assets/server/tls/snakeoil.crt
cp device.key assets/server/tls/snakeoil.key
```
###### 4.3、编译生成ngrok服务端（ngrokd)和客户端（ngrok)程序

```
# 编译选项 交叉编译。注意，不同平台使用不同的GOOS和GOARCH
Linux平台32位系统：GOOS=linux  GOARCH=386
Linux平台64位系统：GOOS=linux  GOARCH=amd64
MAC平台32位系统：GOOS=darwin  GOARCH=386
MAC平台64位系统：GOOS=darwin  GOARCH=amd64
Windows平台32位系统：GOOS=windows  GOARCH=386
Windows平台64位系统：GOOS=windows  GOARCH=amd64
ARM平台：GOOS=linux  GOARCH=arm

# 查看当前系统的选项
go env

# 编译当前系统的ngrok
GOOS=linux GOARCH=amd64 make release-server release-client

# 编译生成Windows平台的ngrok
GOOS=windows GOARCH=amd64 make release-server release-client

#需要其它平台的，可以自行编译
```
编译成功后在当前目录的bin目录下可找到ngrokd文件,该文件就是当前系统的ngrok服务端程序，还有一个windows_amd64文件夹，里面存储着Windows下的ngrok程序

##### 运行ngrokd服务端程序
###### 1、配置域名解析
登录域名服务商网站，对域名进行解析设置，这是我阿里云上购买的域名的解析设置
![](http://ouco65qeg.bkt.clouddn.com/domain_set.png)
###### 2、配置CentOS的防火墙策略

```
# CentOS7默认使用的是firewall作为防火墙，这里改为iptables防火墙.

# 停止firewall
systemctl stop firewalld.service
# 禁止firewall开机启动
systemctl disable firewalld.service
# 查看默认防火墙状态（关闭后显示notrunning，开启后显示running）
firewall-cmd --state

2、iptables防火墙
# 安装
yum install iptables
#编辑防火墙配置文件，将需要开放的端口配置上
vi /etc/sysconfig/iptables

# sample configuration for iptables service
# you can edit this manually or use system-config-firewall
# please do not ask us to add additional ports/services to this default configuration
*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
-A INPUT -p icmp -j ACCEPT
-A INPUT -i lo -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 80 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 8080 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 3306 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 33389 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 4433 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 8000 -j ACCEPT
-A INPUT -p tcp -m state --state NEW -m tcp --dport 4443 -j ACCEPT
-A INPUT -j REJECT --reject-with icmp-host-prohibited
-A FORWARD -j REJECT --reject-with icmp-host-prohibited
COMMIT

:wq! #保存退出

一般添加到“-A INPUT -p tcp -m state --state NEW -m tcp--dport 22 -j ACCEPT”行的上面或者下面，切记不要添加到最后一行，否则防火墙重启后可能不生效。

#最后重启防火墙使配置生效
systemctl restart iptables.service
#设置防火墙开机启动
systemctl enable iptables.service
```
###### 3、启动服务端
```
./bin/ngrokd -tlsKey="assets/server/tls/snakeoil.key" -tlsCrt="assets/server/tls/snakeoil.crt" -domain="ngrok.com"  -httpAddr=":8000" -httpsAddr=":4433" -tunnelAddr=":4443"
```
#### 运行ngrok客户端程序

##### 1、创建配置文件
拷贝刚刚生成的不同平台的客户端到你需要的平台上，在同一目录下，创建一个ngrok.cfg配置文件，可以按自己的情况进行配置

```
server_addr: "ngrok.com:4443"
trust_host_root_certs: false
tunnels:
  http:
    subdomain: "www"
    proto:
      http: "8090"
  rstudio:
    remote_port: 8787
	proto:
	  tcp: "8787"
  spider:
    remote_port: 5000
	proto:
	  tcp: "5000"
  ssh:
    remote_port: 2222
    proto:
      tcp: "22"
  mstsc:
    remote_port: 33389
    proto:
      tcp: "3389"
```
这里全部使用tcp协议配置，这样做的好处是可以设置多个的http隧道（tcp包括了http协议了，之所以可以单独配置http，是为了简化配置而已）。
2、启动客户端
windows下，打开cmd，定位到你刚刚下载的客户端所在目录文件中，输入如下命令：

`ngrok.exe -config ngrok.cfg start http spider rstudio ssh mstsc`

linux下，ngrok 用 & 不能后台运行，这就要使用screen这个命令
首先安装screen
`install screen`
之后运行
`screen -S 任意名字`（例如：ngrok）
然后运行ngrok启动命令
`./ngrok -config ngrok.cfg start http spider rstudio ssh`
最后按快捷键
`ctrl+A+D`
既可以保持ngrok后台运行

成功的启动信息如下

```
Tunnel Status                 online
Version                       1.7/1.7
Forwarding                    http://www.ngrok.com:8080 -> 127.0.0.1:8090
Forwarding                    tcp://ngrok.com:2222 -> 127.0.0.1:22
Forwarding                    tcp://ngrok.com:33389 -> 127.0.0.1:3389
Web Interface                 127.0.0.1:4040
# Conn                        0
Avg Conn Time                 0.00ms
```
#### 大功告成
至此，Ngrok服务组建就完成了！如果你已经在客户端所在的机子上跑了8090端口的web服务，那么现在在浏览器上输入 "www.ngrok.com:8080" ,就可以成功访问了。

安装过程或设置有任何的问题，欢迎留言！

