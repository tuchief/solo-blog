title: 关于Mac下TNT软件无法运行或闪退问题的解决方法
date: '2019-07-24 15:35:53'
updated: '2019-07-24 15:36:40'
tags: [待分类]
permalink: /articles/2019/07/24/1563953752927.html
---
![](https://img.hacpai.com/bing/20180719.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

> Apple苹果公司删除了TNT的证书，很多APP都不能运行了，临时的解决办法，就是自己签名。

#### 开始前的准备工作
1.  安装xCode，从App Store中下载安装，并且至少运行一次。
    
2.  安装Command Line Tools 工具，打开终端工具输入如下命令：  
    `xcode-select --install`  
    弹出后选择继续安装。

#### 开始签名
打开终端工具输入并执行如下命令：  
`codesign --force --deep --sign - /Applications/xxxx.app`

*xxxx.app的程序路径，可以打开访达找到应用程序，找到要签名的APP，直接将其拖入 `终端` 界面，即可自动生成路径。*

现在你在重新运行之前闪退或者运行错误的APP，是不是已经神奇般的可用了呢！