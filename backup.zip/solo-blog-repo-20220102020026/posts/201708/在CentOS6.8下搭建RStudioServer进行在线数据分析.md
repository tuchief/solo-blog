title: 在CentOS6.8下搭建RStudio Server进行在线数据分析
date: '2017-08-07 09:07:03'
updated: '2017-09-26 13:57:47'
tags: [技术, rstudio, centos]
permalink: /rstudio-server
---
### 1.安装EPEL
安装EPEL可以使你更方便的从EPEL来安装R语言，而无需通过其他途径来安装R。如果你运行的是RedHat或CentOS系统的话，你也要安装EPEL来确保RStudio Server正常运行。
不同系统版本安装EPEL的代码如下：
#### 32位系统：
```
$ rpm -Uvh http://download.fedoraproject.org/pub/epel/6/i386/epel-release-6-8.noarch.rpm
```
#### 64位系统：
```
$ rpm -Uvh http://download.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm
```
#### 接下来执行
```
yum upgrade
```
等待安装完成即可

### 2.安装R
当EPEL成功安装后，使用以下代码便可以轻松的进行R语言的安装:
```
#收费版本server pro
sudo yum install R

#免费版本
wget [https://download2.rstudio.org/rstudio-server-rhel-1.0.153-x86_64.rpm](https://download2.rstudio.org/rstudio-server-rhel-1.0.153-x86_64.rpm)
sudo yum install --nogpgcheck rstudio-server-rhel-1.0.153-x86_64.rpm
```
### 3.安装RStudio Server
安装RStudio Server的代码为：
```
wget http://download2.rstudio.org/rstudio-server-rhel-pro-1.0.44-x86_64.rpm
sudo yum install --nogpgcheck rstudio-server-rhel-pro-1.0.44-x86_64.rpm
```
### 4.配置RStudio Server
RStudio Server默认使用的端口是8787，因此在浏览器中输入以下地址便可以看到登录界面：
```
http://host_ip:8787
```

但是你现在还不能使用你的管理员账号来登录，因为RStudio Server禁止系统级用户登录（包括所有ID小于100的用户），这可能是出于安全因素考虑。因此，必须先添加一个满足要求的新用户。


### 5.完成！

<img src="http://ouco65qeg.bkt.clouddn.com/rstudio-server.jpg" width="800" height="500" alt="rstudio-server" align=center />
