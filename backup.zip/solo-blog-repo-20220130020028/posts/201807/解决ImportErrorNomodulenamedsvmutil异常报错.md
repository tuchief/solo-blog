title: '解决ImportError: No module named svmutil异常报错'
date: '2018-07-24 16:25:24'
updated: '2018-07-24 16:27:51'
tags: [python, libsvm, ImportError]
permalink: /articles/2018/07/24/1532420671546.html
---
![](https://img.hacpai.com/bing/20180515.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

#### 异常说明
使用了`from svmutil import *`，执行后发生了`ImportError: No module named svmutil`异常信息

#### 下载libsvm
[点我下载](https://www.csie.ntu.edu.tw/~cjlin/libsvm/)

#### 目录结构
![](http://ouco65qeg.bkt.clouddn.com/2018-07-24-libsvm.png)

#### 解决办法
这里以python语言的使用为例，进入上图目录结构中的python目录
1. 在当前目录下，执行`make`目录，这时候，在当前目录的上层目录上，会多出两个文件，分别是`libsvm.so.2`,`svm.o`，如下图所示：
![](http://ouco65qeg.bkt.clouddn.com/2018-07-24-Xnip2018-07-24_16-20-39.png)
2. 将其中的`svmutil.py`,`svm.py`,`commonutil.py`三个文件，拷贝到使用了`from svmutil import *`语句文件的同级目录上
3. 将`libsvm.so.2`,`svm.o`两个文件，拷贝到`svmutil.py`,`svm.py`,`commonutil.py`三个文件所在目录的上层目录下。
如果放错了位置，执行后会发生`LIBSVM library not found`的异常错误信息。
这是因为，在`svm.py`代码中做了如下定义：
![](http://ouco65qeg.bkt.clouddn.com/2018-07-24-Xnip2018-07-24_16-23-42.png)