title: '升级xcode11后的Git出现xcrun: error: invalid active developer path, missing xcrun的问题'
date: '2019-08-01 09:27:35'
updated: '2019-08-01 09:29:45'
tags: [xcode11, Git]
permalink: /articles/2019/08/01/1564622855254.html
---
昨天升级了一下xcode到了11的版本，结果导致机上的Git在更新时提示了如下的错误信息
```
xcrun: error: invalid active developer path (/Library/Developer/CommandLineTools),
missing xcrun at: /Library/Developer/CommandLineTools/usr/bin/xcrun
```
解决方法，需要重新安装`xcode command line`，如下：
```
xcode-select --install
```
