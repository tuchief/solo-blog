title: chfs (CuteHttpFileServer) 一个可以将文件夹变成网页|免费绿色|HTTP|文件共享服务器工具
date: '2017-12-09 23:25:11'
updated: '2017-12-09 23:25:11'
tags: [软件, chfs, CuteHttpFileServer]
permalink: /articles/2017/12/09/1512833111639.html
---
### 简介

该程序是一个免费的、HTTP协议的文件共享服务器，使用浏览器可以快速访问。它具有以下特点：

*   单个文件，整个软件只有一个可执行程序，无配置文件等其他文件
*   部署简单
*   跨平台运行，支持Windows(xp sp2及其以上版本)和Linux
*   界面简洁，简单易用
*   支持扫码下载和手机端访问，手机与电脑之间共享文件非常方便

与其他常用文件共享方式（如FTP，飞秋）相比，访问者只需要打开浏览器直接访问地址即可，无需额外下载专用客户端。在个人使用以及共享给他人的场景中非常方便快捷。

### 使用

#### 非系统服务运行

该程序是一个控制台程序，可直接双击运行，或在控制台/命令行中运行。可通过命令行参数进行相关配置，如使用'chfs --help'来查看帮助：

usage: chfs [< flags >]

Flags:
  --help            Show context-sensitive help (also try --help-long and
                    --help-man).
  --path=DIRECTORY  Directory where host shared files(Default is current
                    directory).
  --port=PORT       HTTP listening port(Default is 80).
  --version         Show application version.

参数说明：

*   **help:**显示帮助信息*   **path:**你要共享的根目录，默认为程序运行目录。比如：共享"d:\http_shared_root"目录，运行参数："chfs --path="d:\http_shared_root""。**注意：如果路径带有空格，则需要将整个路径用引号包住！***   **port:**程序使用的端口号，默认为80*   **version:**显示程序版本号

几个例子：

//都使用默认参数，共享目录为程序运行目录，监听端口号为80
chfs

//共享目录为D盘，监听端口号为8080
chfs --path="d:" --port=8080

//共享目录为"/home/jack/myshared files"，监听端口号为80
chfs --path="/home/jack/myshared files"

#### 以系统服务运行

本程序不是一个服务程序，所以如果你要以系统服务运行，需要自己创建服务。下面给出Windows平台的创建服务方法(通过NSSM工具)：

1, 将chfs.exe放在指定目录，假设为：d:\program\cutehttpfileserver
2, 到[http://www.nssm.cc/download](http://www.nssm.cc/download)下载nssm
3, 将解压后的nssm程序放在d:\program\cutehttpfileserver中
4, 在d:\program\cutehttpfileserver中运行命令行，或运行命令行并CD至该目录
5, 假设你的服务名称为cute_http_file_service，命令行中输入：nssm install cute_http_file_service
6, NSSM会弹出配置对话框，在该对话框中输入程序路径以及运行参数
7, 启动服务，命令行中输入：nssm start cute_http_file_service

### 问答

#### 怎么可以通过外网访问共享？

你要确保外网能够访问你的服务器，最简单的方法是购买云服务器或虚拟主机。另外，如果你的宽带有独立外网IP，那么也可以在路由中配置虚拟服务器，这样外网就可以通过这个IP进行访问了。如果宽带没有独立IP，则可以使用DDNS即动态域名解析方式。

#### 可不可以给服务绑定个域名，然后通过域名访问？

可以的，可以直接在域名服务商中将你的域名指向你的服务器地址即可。当然，专业用户可以配合Nginx，Apache等HTTP代理服务运行。

#### 我已安装了系统服务，为何浏览器中访问不了？

可能的原因有很多，可通过以下步骤排查：

1.  确保你的浏览器版本是否被支持
2.  确保访客电脑能够访问你的服务器
3.  打开进程管理器查看chfs进程是否存在
4.  停止服务，通过命令行，并且以同样的运行参数运行程序，并访问测试
5.  仍失败的话就联系作者

### 测试说明

#### 运行主机

*   **Windows XP：**√
*   **Windows 10：**√
*   **Debian 9：**√
*   **CentOS 7：**√
*   **其他：**未测试

#### PC浏览器

*   **IE：**11+ ****√
*   **Edge：**√
*   **Firefox：**√
*   **Chrome：**√
*   **Opera：**√
*   **Safari：**√
*   **其他:**未测试

### 相关文件下载地址：

官方网站：[访问](http://iscute.me/chfs)
软件性质：免费