title: centos7安装tensorflow-gpu时遇到的问题汇总
date: '2019-12-22 12:49:10'
updated: '2019-12-22 12:59:09'
tags: [tensorflow, tensorflow-gpu]
permalink: /articles/2019/12/22/1576990150682.html
---
![th1.jpeg](https://img.hacpai.com/file/2019/12/th1-9378862e.jpeg)

#### 1、TypeError: __new__() got an unexpected keyword argument 'serialized_options'

> 更新 protobuf
> `pip install -U protobuf`

#### 2、AttributeError: module 'tensorflow' has no attribute 'gfile'

> tensorflow 包版本问题，版本要求 1.15 &gt;= tensorflow &gt;=1.10，更新 tensorflow 版本
> `pip install -U tensorflow==1.10 -i https://mirrors.aliyun.com/pypi/simple`

#### 3、ImportError: libcublas.so.9.0: cannot open shared object file: No such file or directory

> CUDA 版本要求 9.0，下载对应版本安装
> CUDA 下载地址：`https://developer.nvidia.com/cuda-toolkit-archive`
> 同时 cuDNN 也需要下载和 CUDA 对应的版本，将解压后的文件拷贝到 cuda 的安装目录(默认/usr/local/cuda-9.0)的对应目录下即可；
> cuDNN 下载地址：`https://developer.nvidia.com/rdp/cudnn-archive`

#### tensorflow-gpu 运行环境安装检测程序

```
# -*- coding:utf-8 -*-
import tensorflow as tf

with tf.device('/cpu:0'):
    a = tf.constant ([1.0, 2.0, 3.0], shape=[3], name='a')
    b = tf.constant ([1.0, 2.0, 3.0], shape=[3], name='b')
with tf.device('/gpu:1'):
    c = a + b

sess = tf.Session(config=tf.ConfigProto (allow_soft_placement=True, log_device_placement=True))
# sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))
sess.run(tf.global_variables_initializer())
print (sess.run(c))
```
