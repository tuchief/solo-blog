title: 在apple M1 Pro上构建x86/x64 Docker镜像及使用IDEA打包的设置
date: '2021-12-08 09:40:29'
updated: '2021-12-08 09:40:53'
tags: [m1docker, buildx, IntelliJIDEA, m1pro]
permalink: /articles/2021/12/08/1638927629585.html
---
# M1版本的docker下载

[Download for Mac-Apple Chip](https://desktop.docker.com/mac/main/arm64/Docker.dmg?utm_source=docker&utm_medium=webreferral&utm_campaign=dd-smartbutton&utm_location=module)

[docker官网](https://www.docker.com/get-started)

# 查看镜像平台版本

如果不清楚当前构建的镜像是什么平台的版本，可以使用 `docker inspect image_id` 查看，如下图：

![image.png](https://b3logfile.com/file/2021/12/image-98acd7a6.png)

默认在M1下，通过 `docker build` 来构建的镜像是arm64架构的，此版本只能在arm架构服务器的容器下才能运行，但现在基本上服务器用的都还是x86/x64架构的容器较多，所以还是需要我们在M1上来构建出x86/x64机构的镜像。

# 构建跨平台镜像工具

最新的 Docker Desktop for Mac M1 版本，已经为我们集成了一个实验性的工具**buildx**，通过它，可以编译成各种不同平台架构下的镜像，**buildx**目前支持的平台架构可以通过命令 ` docker buildx ls` 来查看，如下图所示：

![image.png](https://b3logfile.com/file/2021/12/image-1abedf30.png)

可以使用下列命令来构建出符合运行要求的镜像版本

```
docker buildx build --platform=linux/amd64 . -t container_name
```

完成后再根据前面说过的命令来查看当前版本，已经能够看到此时已经按要求被构建出来符合在amd64平台架构下运行的镜像

![image.png](https://b3logfile.com/file/2021/12/image-5a3ebe7c.png)

# 使用IDEA构建镜像

![image.png](https://b3logfile.com/file/2021/12/image-6761c9fd.png)

前面说过，buildx还是实验性的功能，所以在IDEA上需要开启该功能才能正常使用！
