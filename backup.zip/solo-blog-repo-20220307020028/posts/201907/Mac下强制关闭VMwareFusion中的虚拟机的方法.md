title: Mac下强制关闭VMware Fusion中的虚拟机的方法
date: '2019-07-24 14:45:07'
updated: '2019-07-24 14:45:07'
tags: [VMwareFusion, MacOS]
permalink: /articles/2019/07/24/1563950707214.html
---
	今天在使用VMware Fusion中的虚拟机时，发生了错误，重启一直卡着启动不了，然后就强制结束了VMware Fusion，重新运行VMware Fusion了，发现刚刚的虚拟机启动不了了，一直显示正在运行，也没有地方可以重新启动或者关闭该虚拟机的地方。
	方法：打开活动监视器，找到vmware-vmx 进程，强制结束，这样虚拟机就会被强制断电了！
![image.png](https://img.hacpai.com/file/2019/07/image-8991d514.png)
