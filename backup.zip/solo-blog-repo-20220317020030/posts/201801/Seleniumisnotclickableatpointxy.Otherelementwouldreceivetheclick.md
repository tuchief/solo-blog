title: 'Selenium: is not clickable at point (x, y). Other element would receive the
  click'
date: '2018-01-22 10:51:28'
updated: '2018-01-22 10:51:28'
tags: [selenium, python]
permalink: /articles/2018/01/22/1516589481789.html
---
### 描述
在selenium中，使用Chromedriver打开网页`dr.find_element_by_class_name('J_login_trigger').click()`语句能够正常运行，但是，当给Chromedriver设置了`--headless`后，就出现了如下的错误信息！

### 错误信息
>unknown error: Element <a href="javascript:void(0);" onclick="dataLayer.push({'event':'91100','1sttab':'...'});" class="J_login_trigger" data-style="login">登录</a> is not clickable at point (786, 123). Other element would receive the click: <html class="">...</html>
  (Session info: headless chrome=63.0.3239.132)
  (Driver info: chromedriver=2.34.522932 (4140ab217e1ca1bec0c4b4d1b148f3361eb3a03e),platform=Mac OS X 10.13.2 x86_64)

### 解决方法
替换该行代码：
`dr.find_element_by_class_name('J_login_trigger').click()`
替换成：
`dr.execute_script("$('.J_login_trigger').click()")`

