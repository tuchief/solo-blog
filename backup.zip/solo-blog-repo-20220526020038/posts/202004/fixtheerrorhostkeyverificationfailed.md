title: fix the error “host key verification failed”
date: '2020-04-10 11:29:09'
updated: '2020-04-10 11:31:55'
tags: [技术, ssh]
permalink: /articles/2020/04/10/1586489349741.html
---
![someoneisdoingsomethingnasty604x270.png](https://img.hacpai.com/file/2020/04/someoneisdoingsomethingnasty604x270-49606135.png)

#### 错误信息

在使用iterms通过ssh连接某服务器时，报了如下提示：

> @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
> @    WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!     @
> @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
> IT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!
> Someone could be eavesdropping on you right now (man-in-the-middle attack)!
> It is also possible that the RSA host key has just been changed.
> The fingerprint for the RSA key sent by the remote host is
> dd:cf:50:31:7a:78:93:13:dd:99:67:c2:a2:19:22:13.
> Please contact your system administrator.
> Add correct host key in /home/user01/.ssh/known_hosts to get rid of this message.
> Offending key in /home/lcz/.ssh/known_hosts:7
> RSA host key for 192.168.21.49 has changed and you have requested strict checking.
> Host key verification failed.

#### 修复方式：

1. 手动删除旧的秘钥

```
# vi ~/.ssh/known_hosts
192.168.1.113 ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBLrY91bQOihgFZQ2Ay9KiBG0rg51/YxJAK7dvAIopRaWzFEEis3fQJiYZNLzLgQtlz6pIe2tj9m/Za33W6WirN8=
192.168.19.11 ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCrY/m16MdFt/Ym51Cc7kxZW3R2pcHV1jlOclv6sXix1UhMuPdtoboj+b7+NLlTcjfrUccL+1bkg8EblYucymeU=
# 根据提示的IP地址，将该秘钥删除
192.168.21.49 ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCrY/m16MdFt/Ym51Cc7kxZW3R2pcHV1jlOclv6sXix1UhMuPdtoboj+b7+NLlTcjfrUccL+1bkg8EblYucymeU=
```

2. 使用ssh-keygen目录删除旧秘钥

```
$ ssh-keygen -R [hostname | IP address]
```

```
$ ssh-keygen -R 192.168.21.49
# Host 192.168.21.49 found: line 4
/home/user01/.ssh/known_hosts updated.
Original contents retained as /home/user01/.ssh/known_hosts.old
```

最后，再重新使用ssh连接服务器；

```
$ ssh root@192.168.21.49
The authenticity of host '192.168.21.49(192.168.21.49)' can't be established.
ECDSA key fingerprint is SHA256:V+iGp3gwSlnpbtYv4Niq6tcMMSZivSnYWQIaJnUvHb4.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '192.168.21.49' (ECDSA) to the list of known hosts.
```
