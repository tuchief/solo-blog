title: 在VM中更新了WIN10系统之后，界面黑屏弹出个性化设置（未响应）
date: '2020-03-12 17:17:29'
updated: '2020-03-13 10:13:21'
tags: [VMwareFusion, explorer.exe]
permalink: /articles/2020/03/12/1584004649547.html
---
![](https://img.hacpai.com/file/2020/03/v28c8874b559ba9a1ce835349f5ddcae40b-580f566a.png "v28c8874b559ba9a1ce835349f5ddcae40b.png")

解决方法如下图所示：

```
使用快捷键方式 Ctrl+Alt+Del，打开任务管理器，文件-运行新任务，输入 `explorer.exe` 点击确定，等待完成，一会儿就能看见界面了！
```

![](https://img.hacpai.com/file/2020/03/image-86dea874.png "image.png")
