title: 在CentOS7中添加自启动服务和脚本的操作
date: '2017-08-24 09:33:31'
updated: '2017-08-24 09:33:31'
tags: [操作系统, 技术, centos7]
permalink: /articles/2017/08/24/1503538239369.html
---
> **1、添加开机自启服务**

我这里以docker 服务为例，设置如下两条命令即可：

```
# systemctl enable docker.service  #设置docker服务为自启动服务 相当于我们的 chkconfig docker on
# sysstemctl start  docker.service #启动docker服务
```

> **2、添加开机自启脚本**

在centos7中增加脚本有两种常用的方法，以脚本StartTomcat.sh为例：

```
#!/bin/bash
# description:开机自启脚本
/usr/local/tomcat/bin/startup.sh  #启动tomcat
```

**方法一:**
1、赋予脚本可执行权限（/opt/script/StartTomcat.sh是你的脚本路径）

```
# chmod +x /opt/script/StartTomcat.sh
```

2、打开/etc/rc.d/rc.local文件，在末尾增加如下内容

```
echo "/opt/script/StartTomcat.sh" >> /etc/rc.d/rc.local
```

3、在centos7中，/etc/rc.d/rc.local的权限被降低了，所以需要执行如下命令赋予其可执行权限

```
chmod +x /etc/rc.d/rc.local
```

**方法二：**
1、将脚本移动到/etc/rc.d/init.d目录下

```
# mv  /opt/script/StartTomcat.sh /etc/rc.d/init.d
```

2、增加脚本的可执行权限

```
chmod +x  /etc/rc.d/init.d/StartTomcat.sh
```

3、添加脚本到开机自动启动项目中

```
cd /etc/rc.d/init.d
chkconfig --add StartTomcat.sh
chkconfig StartTomcat.sh on
```