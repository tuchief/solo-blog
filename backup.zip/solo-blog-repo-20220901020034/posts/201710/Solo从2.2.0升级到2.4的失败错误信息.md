title: Solo从2.2.0升级到2.4的失败错误信息
date: '2017-10-12 23:23:49'
updated: '2017-10-12 23:23:49'
tags: [Solo]
permalink: /articles/2017/10/12/1507821825352.html
---
### 错误日志信息如下：
```
[INFO ]-[2017-10-12 23:16:45]-[org.b3log.solo.SoloServletListener:153]: Solo is running [http://www.tuchief.com]
[ERROR]-[2017-10-12 23:17:08]-[org.b3log.latke.servlet.HttpControl:104]: Request [
    method=GET,
    URL=http://www.tuchief.com/,
    contentType=null,
    characterEncoding=UTF-8,
    local=[
        addr=172.31.205.50,
        port=80,
        name=172.31.205.50],
    remote=[
        addr=36.248.245.76,
        port=10028,
        host=36.248.245.76],
    headers=[
        Cookie=visited="[\"/\",\"/tags.html\"]"; b3log-latke="{\"userPassword\":\"4f7fb3703b192ce9c07922f8a24172fe\",\"userEmail\":\"call1832@gmail.com\"}"; JSESSIONID=1112oghw3t40kfo4lmj54tq4o; skin=
        Cache-Control=max-age=0
        Accept=text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8
        Upgrade-Insecure-Requests=1
        Connection=keep-alive
        User-Agent=Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36
        Host=www.tuchief.com
        DNT=1
        Accept-Encoding=gzip, deflate
        Accept-Language=zh-CN,zh;q=0.8
    ]
] processing failed
java.lang.reflect.InvocationTargetException
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
        at java.lang.reflect.Method.invoke(Method.java:498)
        at org.b3log.latke.servlet.handler.MethodInvokeHandler.handle(MethodInvokeHandler.java:58)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.handler.AdviceHandler.handle(AdviceHandler.java:108)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.handler.ArgsHandler.handle(ArgsHandler.java:60)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.handler.RequestDispatchHandler.handle(RequestDispatchHandler.java:92)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.handler.RequestPrepareHandler.handle(RequestPrepareHandler.java:45)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.handler.StaticResourceHandler.handle(StaticResourceHandler.java:119)
        at org.b3log.latke.servlet.HttpControl.nextHandler(HttpControl.java:99)
        at org.b3log.latke.servlet.DispatcherServlet.service(DispatcherServlet.java:84)
        at javax.servlet.http.HttpServlet.service(HttpServlet.java:790)
        at org.eclipse.jetty.servlet.ServletHolder.handle(ServletHolder.java:808)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1669)
        at org.b3log.solo.filter.InitCheckFilter.doFilter(InitCheckFilter.java:87)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.b3log.solo.filter.PermalinkFilter.doFilter(PermalinkFilter.java:92)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.b3log.latke.servlet.filter.EncodingFilter.doFilter(EncodingFilter.java:71)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.eclipse.jetty.servlet.ServletHandler.doHandle(ServletHandler.java:585)
        at org.eclipse.jetty.server.handler.ScopedHandler.handle(ScopedHandler.java:143)
        at org.eclipse.jetty.security.SecurityHandler.handle(SecurityHandler.java:577)
        at org.eclipse.jetty.server.session.SessionHandler.doHandle(SessionHandler.java:223)
        at org.eclipse.jetty.server.handler.ContextHandler.doHandle(ContextHandler.java:1127)
        at org.eclipse.jetty.servlet.ServletHandler.doScope(ServletHandler.java:515)
        at org.eclipse.jetty.server.session.SessionHandler.doScope(SessionHandler.java:185)
        at org.eclipse.jetty.server.handler.ContextHandler.doScope(ContextHandler.java:1061)
        at org.eclipse.jetty.server.handler.ScopedHandler.handle(ScopedHandler.java:141)
        at org.eclipse.jetty.server.handler.HandlerWrapper.handle(HandlerWrapper.java:97)
        at org.eclipse.jetty.server.Server.handle(Server.java:497)
        at org.eclipse.jetty.server.HttpChannel.handle(HttpChannel.java:310)
        at org.eclipse.jetty.server.HttpConnection.onFillable(HttpConnection.java:245)
        at org.eclipse.jetty.io.AbstractConnection$2.run(AbstractConnection.java:540)
        at org.eclipse.jetty.util.thread.QueuedThreadPool.runJob(QueuedThreadPool.java:635)
        at org.eclipse.jetty.util.thread.QueuedThreadPool$3.run(QueuedThreadPool.java:555)
        at java.lang.Thread.run(Thread.java:748)
Caused by: java.lang.NullPointerException
        at org.b3log.solo.processor.util.Filler.fillIndexArticles(Filler.java:204)
        at org.b3log.solo.processor.util.Filler_$$_jvst5ee_24._d5fillIndexArticles(Filler_$$_jvst5ee_24.java)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
        at java.lang.reflect.Method.invoke(Method.java:498)
        at org.b3log.latke.ioc.bean.JavassistMethodHandler.invoke(JavassistMethodHandler.java:106)
        at org.b3log.solo.processor.util.Filler_$$_jvst5ee_24.fillIndexArticles(Filler_$$_jvst5ee_24.java)
        at org.b3log.solo.processor.IndexProcessor.showIndex(IndexProcessor.java:152)
        at org.b3log.solo.processor.IndexProcessor_$$_jvst5ee_3d._d8showIndex(IndexProcessor_$$_jvst5ee_3d.java)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
        at java.lang.reflect.Method.invoke(Method.java:498)
        at org.b3log.latke.ioc.bean.JavassistMethodHandler.invoke(JavassistMethodHandler.java:106)
        at org.b3log.solo.processor.IndexProcessor_$$_jvst5ee_3d.showIndex(IndexProcessor_$$_jvst5ee_3d.java)
        ... 43 more
[ERROR]-[2017-10-12 23:17:09]-[org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer:138]: FreeMarker renders error
FreeMarker template error:
The following has evaluated to null or missing:
==> blogTitle  [in template "index.ftl" at line 5, column 25]
----
Tip: If the failing expression is known to be legally refer to something that's sometimes null or missing, either specify a default value like myOptionalVar!myDefault, or use <#if myOptionalVar??>when-present<#else>when-missing</#if>. (These only cover the last step of the expression; to cover the whole expression, use parenthesis: (myOptionalVar.foo)!myDefault, (myOptionalVar.foo)??
----
----
FTL stack trace ("~" means nesting-related):
        - Failed at: ${blogTitle}  [in template "index.ftl" at line 5, column 23]
        - Reached through: @head title="${blogTitle}"  [in template "index.ftl" at line 5, column 9]
----
Java stack trace (for programmers):
----
freemarker.core.InvalidReferenceException: [... Exception message was already printed; see it above ...]
        at freemarker.core.InvalidReferenceException.getInstance(InvalidReferenceException.java:131)
        at freemarker.core.EvalUtil.coerceModelToString(EvalUtil.java:355)
        at freemarker.core.Expression.evalAndCoerceToString(Expression.java:82)
        at freemarker.core.DollarVariable.accept(DollarVariable.java:41)
        at freemarker.core.Environment.visit(Environment.java:324)
        at freemarker.core.MixedContent.accept(MixedContent.java:54)
        at freemarker.core.Environment.visit(Environment.java:324)
        at freemarker.core.Environment.renderElementToString(Environment.java:2196)
        at freemarker.core.StringLiteral.evalAndCoerceToString(StringLiteral.java:96)
        at freemarker.core.StringLiteral._eval(StringLiteral.java:73)
        at freemarker.core.Expression.eval(Expression.java:78)
        at freemarker.core.Environment.setMacroContextLocalsFromArguments(Environment.java:739)
        at freemarker.core.Environment.invoke(Environment.java:689)
        at freemarker.core.UnifiedCall.accept(UnifiedCall.java:84)
        at freemarker.core.Environment.visit(Environment.java:324)
        at freemarker.core.MixedContent.accept(MixedContent.java:54)
        at freemarker.core.Environment.visit(Environment.java:324)
        at freemarker.core.Environment.process(Environment.java:302)
        at freemarker.template.Template.process(Template.java:325)
        at org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer.genHTML(AbstractFreeMarkerRenderer.java:162)
        at org.b3log.latke.servlet.renderer.freemarker.AbstractFreeMarkerRenderer.render(AbstractFreeMarkerRenderer.java:133)
        at org.b3log.latke.servlet.DispatcherServlet.result(DispatcherServlet.java:111)
        at org.b3log.latke.servlet.DispatcherServlet.service(DispatcherServlet.java:89)
        at javax.servlet.http.HttpServlet.service(HttpServlet.java:790)
        at org.eclipse.jetty.servlet.ServletHolder.handle(ServletHolder.java:808)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1669)
        at org.b3log.solo.filter.InitCheckFilter.doFilter(InitCheckFilter.java:87)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.b3log.solo.filter.PermalinkFilter.doFilter(PermalinkFilter.java:92)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.b3log.latke.servlet.filter.EncodingFilter.doFilter(EncodingFilter.java:71)
        at org.eclipse.jetty.servlet.ServletHandler$CachedChain.doFilter(ServletHandler.java:1652)
        at org.eclipse.jetty.servlet.ServletHandler.doHandle(ServletHandler.java:585)
        at org.eclipse.jetty.server.handler.ScopedHandler.handle(ScopedHandler.java:143)
        at org.eclipse.jetty.security.SecurityHandler.handle(SecurityHandler.java:577)
        at org.eclipse.jetty.server.session.SessionHandler.doHandle(SessionHandler.java:223)
        at org.eclipse.jetty.server.handler.ContextHandler.doHandle(ContextHandler.java:1127)
        at org.eclipse.jetty.servlet.ServletHandler.doScope(ServletHandler.java:515)
        at org.eclipse.jetty.server.session.SessionHandler.doScope(SessionHandler.java:185)
        at org.eclipse.jetty.server.handler.ContextHandler.doScope(ContextHandler.java:1061)
        at org.eclipse.jetty.server.handler.ScopedHandler.handle(ScopedHandler.java:141)
        at org.eclipse.jetty.server.handler.HandlerWrapper.handle(HandlerWrapper.java:97)
        at org.eclipse.jetty.server.Server.handle(Server.java:497)
        at org.eclipse.jetty.server.HttpChannel.handle(HttpChannel.java:310)
        at org.eclipse.jetty.server.HttpConnection.onFillable(HttpConnection.java:245)
        at org.eclipse.jetty.io.AbstractConnection$2.run(AbstractConnection.java:540)
        at org.eclipse.jetty.util.thread.QueuedThreadPool.runJob(QueuedThreadPool.java:635)
        at org.eclipse.jetty.util.thread.QueuedThreadPool$3.run(QueuedThreadPool.java:555)
        at java.lang.Thread.run(Thread.java:748)
```