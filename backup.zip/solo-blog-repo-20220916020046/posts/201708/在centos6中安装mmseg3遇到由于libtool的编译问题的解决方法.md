title: 在centos6中安装mmseg3遇到由于libtool的编译问题的解决方法
date: '2017-08-08 03:20:22'
updated: '2017-08-10 03:06:00'
tags: [技术, libtool, centos, mmseg, make]
permalink: /articles/2017/08/08/1502162392438.html
---
#### 问题描述
> libtool: Version mismatch error.  This is libtool 2.4.6, but the
libtool: definition of this LT_INIT comes from libtool 2.2.6b.
libtool: You should recreate aclocal.m4 with macros from libtool 2.2.6 Debian-2.2.6a-4
libtool: and run autoconf again.
make[2]: *** [wktools4] Error 63
make[2]: Target `all' not remade because of errors.
make[1]: *** [all-recursive] Error 1
make: *** [all] Error 2
*** Exited with status: 2 ***

产生该问题的原因是因为系统的libtool版本与mmseg3安装目录下的libtool版本不对应造成的；

#### 解决方法
可以使用下面的方式将系统的libtool版本与mmseg3里的libtool版本对应：
* 卸载原来的旧版本
```
yum remove libtool
```
* 下载
```
wget http://mirrors.ustc.edu.cn/gnu/libtool/libtool-2.4.6.tar.gz
```
* 解压并进入目录
```
tar zxvf libtool-2.4.6.tar.gz && cd libtool-2.4.6
```
* 配置
```
./configure --prefix=/usr
```
* 编译并安装
```
make && make install
```
* 重新安装mmseg3
```
cd mmseg-3.2.14
rm -rf aclocal.m4
./bootstrap
./configure --prefix=/usr/local/mmseg3
make && sudo make install
```