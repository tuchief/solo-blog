title: 'Windows下启动Redis时出现Creating Server TCP listening socket 0.0.0.0:6379: bind:
  No such file or directory'
date: '2020-04-02 11:38:37'
updated: '2020-04-02 11:43:21'
tags: [技术, redis, 工具]
permalink: /articles/2020/04/02/1585798717192.html
---
![image.png](https://img.hacpai.com/file/2020/04/image-ea73f55d.png)

Windows中，安装完Redis后，在Redis的安装目录下，使用CMD执行了 `redis-server.exe redis.windows.conf` 命令，提示了如下的错误信息：

```
[6845] 02 Apr 23:11:58.976 # Creating Server TCP listening socket 0.0.0.0:6379: bind: No such file or directory
```

解决方案：

按照顺序执行下列命令后，重新运行启动命令；

```
redis-cli.exe
shutdown
exit
redis-server.exe redis.windows.conf
```
