title: 'centos7在使用yum update报错 error: unpacking of archive failed on file ...... cpio:
  open的解决方法'
date: '2019-12-19 00:01:06'
updated: '2019-12-22 13:04:27'
tags: [centos7]
permalink: /articles/2019/12/19/1576684866569.html
---
![th3.jpeg](https://img.hacpai.com/file/2019/12/th3-08a6cf52.jpeg)

今天在阿里云centos7下，使用`sudo yum update`更新时，发生了如下错误提示：
```
error: NetworkManager-1:1.18.0-5.el7_7.1.x86_64: install failed

 Updating   : gdb-7.6.1-115.el7.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          51/183

 Updating   : libcom_err-devel-1.42.9-16.el7.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             52/183

 Updating   : krb5-devel-1.15.1-37.el7_7.2.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               53/183

Error unpacking rpm package krb5-devel-1.15.1-37.el7_7.2.x86_64

error: unpacking of archive failed on file /usr/sbin/gss-server;5dfa47c0: cpio: open

 Updating   : rpm-build-4.11.3-40.el7.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    54/183

error: krb5-devel-1.15.1-37.el7_7.2.x86_64: install failed

 Updating   : 1:NetworkManager-tui-1.18.0-5.el7_7.1.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      55/183

 Updating   : policycoreutils-python-2.5-33.el7.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          56/183

Error unpacking rpm package policycoreutils-python-2.5-33.el7.x86_64

error: unpacking of archive failed on file /usr/sbin/semanage;5dfa47c0: cpio: open

 Updating   : yum-3.4.3-163.el7.centos.noarch                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   57/183

error: policycoreutils-python-2.5-33.el7.x86_64: install failed

 Updating   : 7:device-mapper-event-1.02.158-2.el7_7.2.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   58/183

Error unpacking rpm package 7:device-mapper-event-1.02.158-2.el7_7.2.x86_64

error: unpacking of archive failed on file /usr/sbin/dmeventd;5dfa47c0: cpio: open

 Updating   : 1:grub2-tools-extra-2.02-0.80.el7.centos.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   59/183

Error unpacking rpm package 1:grub2-tools-extra-2.02-0.80.el7.centos.x86_64

error: device-mapper-event-7:1.02.158-2.el7_7.2.x86_64: install failed

error: unpacking of archive failed on file /usr/sbin/grub2-ofpathname;5dfa47c0: cpio: open

 Updating   : dnsmasq-2.76-10.el7_7.1.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    60/183

Error unpacking rpm package dnsmasq-2.76-10.el7_7.1.x86_64

error: grub2-tools-extra-1:2.02-0.80.el7.centos.x86_64: install failed

error: unpacking of archive failed on file /usr/sbin/dnsmasq;5dfa47c0: cpio: open

 Updating   : audit-2.8.5-4.el7.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          61/183

Error unpacking rpm package audit-2.8.5-4.el7.x86_64

error: dnsmasq-2.76-10.el7_7.1.x86_64: install failed

error: unpacking of archive failed on file /sbin/audispd;5dfa47c0: cpio: open

 Updating   : 12:dhclient-4.2.5-77.el7.centos.x86_64                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            62/183

Error unpacking rpm package 12:dhclient-4.2.5-77.el7.centos.x86_64

error: audit-2.8.5-4.el7.x86_64: install failed

error: unpacking of archive failed on file /usr/sbin/dhclient;5dfa47c0: cpio: open

 Updating   : tuned-2.11.0-5.el7_7.1.noarch                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     63/183

Error unpacking rpm package tuned-2.11.0-5.el7_7.1.noarch
```

看error信息，怀疑是目录属性的问题，所以查看了一下目录属性：
```
[root@ebs-64959 usr]# lsattr /usr

-------------e-- /usr/src

----i-----I--e-- /usr/sbin

-------------e-- /usr/lib

-------------e-- /usr/libexec

-------------e-- /usr/man

-------------e-- /usr/share

----------I--e-- /usr/bin

----------I--e-- /usr/lib64

----------I--e-- /usr/include

-------------e-- /usr/etc

-------------e-- /usr/local

-------------e-- /usr/games
```

可以发现，在/usr/sbin中有 i 属性，这会导致目录被锁定，即便是管理员也无法被修改，所以需要使用如下命令来去除该属性：
```
[root@ebs-64959 usr]# chattr -i /usr/sbin
```

之后在重新执行 `sudo yum update` 命令
