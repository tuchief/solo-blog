title: 'install csft-4.1 configure: error: cannot run C compiled programs. by centos6'
date: '2017-08-08 04:41:02'
updated: '2017-08-08 04:44:52'
tags: [技术, centos6, csft, sphinx, coreseek]
permalink: /articles/2017/08/08/1502167261988.html
---
#### 问题描述

> checking whether to compile debug version... no
checking for gcc... gcc
checking for C compiler default output file name... a.out
checking whether the C compiler works... configure: error: in `/usr/local/src/coreseek-4.1-beta/csft-4.1':
configure: error: cannot run C compiled programs.
If you meant to cross compile, use `--host'.
See `config.log' for more details.
[root@centos csft-4.1]# make -j2 && sudo make install
make: *** No targets specified and no makefile found.  Stop.

#### 解决方法
在命令后增加`--host=arm`参数即可
```
./configure --prefix=/usr/local/coreseek ...... --host=arm
```