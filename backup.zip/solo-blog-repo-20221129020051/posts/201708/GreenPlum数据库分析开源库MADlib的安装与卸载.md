title: GreenPlum 数据库分析开源库 MADlib 的安装与卸载
date: '2017-08-10 03:04:02'
updated: '2017-08-10 06:05:20'
tags: [技术, centos7, GreenPlum, MADlib]
permalink: /articles/2017/08/10/1502334175804.html
---
### MADlib科普
  MADlib是Pivotal公司与伯克利大学合作的一个开源机器学习库，提供了精确的数据并行实现、统计和机器学习方法对结构化和非结构化数据进行分析，主要目的是扩展数据库的分析能力，可以非常方便的加载到数据库中, 扩展数据库的分析功能，2015年7月MADlib成为Apache软件基金会的孵化项目，其最新版本为MADlib1.11，可以用在Greenplum、PostgreSQL和HAWQ等数据库系统中。
  官网地址：http://madlib.incubator.apache.org/;

### 设计思想
驱动MADlib架构的主要思想与Hadoop是一致的，主要体现在以下方面：

*   操作数据库内的本地数据，不在多个运行时环境中进行不必要的数据移动。
*   充分利用数据库引擎的功能，但将机器学习逻辑从特定数据库的实现细节中分离出来。
*   利用MPP无共享技术提供的并行性和可扩展性，如Greenplum数据库和HAWQ。
*   执行的维护活动对Apache社区和正在进行的学术研究开放。

  如果只用一句话总结MADlib的特点，就如标题所述，可以用SQL玩转数据分析、数据挖掘和机器学习。

### 特征
（1）分类
  如果所需的输出实质上是分类的，可以使用分类方法建立模型，预测新数据会属于哪一类。分类的目标是能够将输入记录标记为正确的类别。
  分类的例子：假设有描述人口统计的数据，以及个人申请贷款和贷款违约历史数据，那么我们就能建立一个模型，描述新的人口统计数据集合贷款违约的可能性。此场景下输出的分类为“违约”和“正常”两类。

（2）回归
  如果所需的输出具有连续性，我们使用回归方法建立模型，预测输出值。
  回归的例子：如果有真实的描述房地产属性的数据，我们就可以建立一个模型，预测基于房屋已知特征的售价。因为输出反应了连续的数值而不是分类，所以该场景是一个回归问题。

（3）聚类
  识别数据分组，一组中的数据项比其它组的数据项更相似。
  聚类的例子：在客户细分分析中，目标是识别客户行为相似特征组，以便针对不同特征的客户设计各种营销活动，以达到市场目的。如果提前了解客户细分情况，这将是一个受控的分类任务。当我们让数据识别自身分组时，这就是一个聚类任务。

（4）主题建模
  主题建模与聚类相似，也是确定彼此相似的数据组。但这里的相似通常特指在文本领域中，具有相同主题的文档。

（5）关联规则挖掘
  又叫做购物篮分析或频繁项集挖掘。相对于随机发生，确定哪些事项更经常一起发生，指出事项之间的潜在关系。
  关联规则挖掘的例子：在一个网店应用中，关联规则挖掘可用于确定哪些商品倾向于被一起售出。然后将这些商品输入到客户推荐引擎中，提供促销机会，如著名的啤酒与尿布的故事。

（6）描述性统计
  描述性统计不提供模型，因此不被认为是一种机器学习方法。但描述性统计有助于向分析人员提供信息以了解基础数据，为数据提供有价值的解释，可能影响数据模型的选择。
  描述性统计的例子：计算数据集中每个变量内的数据分布，可以帮助分析式理解哪些变量应被视为分类变量，哪些变量是连续性变量，以及值的分布情况。

（7）模型验证
  如果不了解一个模型的准确性就开始使用它，会导致糟糕的结果。正因如此，理解模型存在的问题，并用测试数据评估模型的精度显得尤为重要。需要将训练数据和测试数据分离，频繁进行数据分析，验证统计模型的有效性，评估模型不过分拟合训练数据。N-fold交叉验证也经常被使用。

### 功能图
<img src="http://ouco65qeg.bkt.clouddn.com/madlib_opt.jpg" width="600" height="400" align="center" />

### 安装前检查

安装MADlib开始前，检查python和m4版本

- 操作系统：CentOS7，这个没限制啦，6的也行，无碍！5的我就不知道了......:smiling_imp:

- 我的python版本为2.6，应该2.6及其以上的都行

	`python --version`

- 在使用gppkg安装MADlib的过程中，报了m4的版本问题，所以我直接安装了最新版本的m4

	`sudo yum install m4`

### 开始安装

1.打开https://network.pivotal.io/products/pivotal-gpdb

2.选择对应的GreenPlum版本，我的是4.3.15

3.找到MADlib，使用wget下载包
<img src="http://ouco65qeg.bkt.clouddn.com/greenplum_down_madlib.jpg" width="600" height="700" align="center" />

4.开始解压，使用gppkg安装
```
#解压缩
[root@mdw tmp]$ tar -zxvf madlib-ossv1.11_pv1.9.8_gpdb4.3orca-rhel5-x86_64.tar.gz


#安装
[root@mdw tmp]$ gppkg -i madlib-ossv1.11_pv1.9.8_gpdb4.3orca-rhel5-x86_64.gppkg


[root@mdw tmp]$ su gpadmin
#在指定数据库中部署MADlib
[gpadmin@mdw tmp]$ $GPHOME/madlib/bin/madpack install -s madlib -p greenplum -c gpadmin@mdw:5432/csmar
madpack.py : INFO : Detected Greenplum DB version 4.3.15.
madpack.py : INFO : *** Installing MADlib ***
madpack.py : INFO : MADlib tools version    = 1.11 (/usr/local/greenplum-db-4.3.15.0/madlib/Versions/1.11/bin/../madpack/madpack.py)
madpack.py : INFO : MADlib database version = None (host=mdw:5432, db=csmar, schema=madlib)
madpack.py : INFO : Testing PL/Python environment...
madpack.py : INFO : > PL/Python environment OK (version: 2.6.2)
madpack.py : INFO : Installing MADlib into MADLIB schema...
madpack.py : INFO : > Creating MADLIB schema
madpack.py : INFO : > Creating MADLIB.MigrationHistory table
madpack.py : INFO : > Writing version info in MigrationHistory table
madpack.py : INFO : > Creating objects for modules:
madpack.py : INFO : > - array_ops
madpack.py : INFO : > - bayes
madpack.py : INFO : > - crf
madpack.py : INFO : > - elastic_net
madpack.py : INFO : > - graph
madpack.py : INFO : > - linalg
madpack.py : INFO : > - pmml
madpack.py : INFO : > - prob
madpack.py : INFO : > - sketch
madpack.py : INFO : > - svec
madpack.py : INFO : > - svm
madpack.py : INFO : > - tsa
madpack.py : INFO : > - stemmer
madpack.py : INFO : > - conjugate_gradient
madpack.py : INFO : > - knn
madpack.py : INFO : > - lda
madpack.py : INFO : > - stats
madpack.py : INFO : > - svec_util
madpack.py : INFO : > - utilities
madpack.py : INFO : > - assoc_rules
madpack.py : INFO : > - convex
madpack.py : INFO : > - glm
madpack.py : INFO : > - linear_systems
madpack.py : INFO : > - recursive_partitioning
madpack.py : INFO : > - regress
madpack.py : INFO : > - sample
madpack.py : INFO : > - summary
madpack.py : INFO : > - kmeans
madpack.py : INFO : > - pca
madpack.py : INFO : > - validation
madpack.py : INFO : MADlib 1.11 installed successfully in MADLIB schema.


#安装完成
[gpadmin@mdw root]$ psql -d csmar
could not change directory to "/root"
psql (8.2.15)
Type "help" for help.

csmar=# \dn
       List of schemas
        Name        |  Owner
--------------------+---------
 gp_toolkit         | gpadmin
 information_schema | gpadmin
 madlib             | gpadmin
 pg_aoseg           | gpadmin
 pg_bitmapindex     | gpadmin
 pg_catalog         | gpadmin
 pg_toast           | gpadmin
 public             | gpadmin
(8 rows)
```
#### 验证安装
```
[root@mdw bin]# $GPHOME/madlib/bin/madpack install-check -c gpadmin@mdw:5432/csmar -s madlib -p greenplum
madpack.py : INFO : Detected Greenplum DB version 4.3.15.
TEST CASE RESULT|Module: array_ops|array_ops.sql_in|PASS|Time: 8325 milliseconds
TEST CASE RESULT|Module: bayes|gaussian_naive_bayes.sql_in|PASS|Time: 4640 milliseconds
TEST CASE RESULT|Module: bayes|bayes.sql_in|PASS|Time: 12374 milliseconds
TEST CASE RESULT|Module: crf|crf_train_small.sql_in|PASS|Time: 7397 milliseconds
TEST CASE RESULT|Module: crf|crf_train_large.sql_in|PASS|Time: 10346 milliseconds
TEST CASE RESULT|Module: crf|crf_test_small.sql_in|PASS|Time: 8349 milliseconds
TEST CASE RESULT|Module: crf|crf_test_large.sql_in|PASS|Time: 8851 milliseconds
......
```

### 卸载

#### 删除madlib模式

  方法1，使用madpack部署应用程序。
  `$GPHOME/madlib/bin/madpack uninstall -c gpadmin@mdw:5432/csmar -s madlib -p greenplum`

  方法2，使用SQL命令手工删除模式。
  `drop schema madlib cascade;`

#### 删除其它遗留数据库对象

（1）删除模式
  如果测试中途出错，数据库中可能包含测试的模式，这些模式名称的前缀都是madlib_installcheck_，只能手工执行SQL命令删除这些模式：
  `drop schema madlib_installcheck_kmeans cascade;  `

（2）删除用户
  如果存在遗留的测试用户，则删除它。
  `drop user if exists ...;  `

#### 删除MADlib rpm包

（1）查询包名
```
[gpadmin@mdw root]$ gppkg -q --all
20170810:11:31:15:001550 gppkg:mdw:gpadmin-[INFO]:-Starting gppkg with args: -q --all
madlib-ossv1.11_pv1.9.8_gpdb4.3orca
```

（2）删除rpm包
  `gppkg -r madlib-ossv1.11_pv1.9.8_gpdb4.3orca`