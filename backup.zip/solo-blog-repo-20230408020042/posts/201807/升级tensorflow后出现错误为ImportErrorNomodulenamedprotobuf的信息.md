title: '升级tensorflow后，出现错误为 ImportError: No module named protobuf 的信息'
date: '2018-07-24 16:32:35'
updated: '2018-07-24 16:33:09'
tags: [python, protobuf, google]
permalink: /articles/2018/07/24/1532421155317.html
---
![](https://img.hacpai.com/bing/20180228.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)

卸载 protobuf、google，之后重新安装即可
```
pip uninstall protobuf
pip uninstall google
pip install google
pip install protobuf
```