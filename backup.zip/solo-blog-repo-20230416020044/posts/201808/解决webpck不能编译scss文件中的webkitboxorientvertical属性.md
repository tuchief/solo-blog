title: '解决webpck不能编译scss文件中的 -webkit-box-orient: vertical 属性'
date: '2018-08-20 23:54:24'
updated: '2018-08-20 23:57:41'
tags: [webpack, scss]
permalink: /articles/2018/08/20/1534780454139.html
---
![](http://ouco65qeg.bkt.clouddn.com/2018-08-20-scss.png)
#### 问题描述
如下属性是用来处理多行文本溢出的，但是在webpack编译之后，检查元素样式并没有`-webkit-box-orient: vertical`这个属性，而其它几个属性都有。
```
width: 130px;
overflow: hidden;
text-overflow: ellipsis;
display: -webkit-box;
-webkit-line-clamp: 2;
-webkit-box-orient: vertical;
```

#### 解决方法
```
/*! autoprefixer: off */
-webkit-box-orient: vertical;
/* autoprefixer: on */
```