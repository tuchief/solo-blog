title: 关于Final Cut Pro在母版文件导出中，如果分辨率无法被修改的话
date: '2019-08-25 10:38:51'
updated: '2019-08-25 10:39:32'
tags: [待分类]
permalink: /articles/2019/08/25/1566700731618.html
---
![](https://img.hacpai.com/bing/20180518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

在大多数情况下，Final Cut Pro 会基于您添加到项目的第一个素材片段的属性来自动管理项目设置，但是如果您需要进行修改，就拿分辨率的修改来说，可以进行如下操作

依次打开窗口—项目属性，可以在界面右侧看见属性对话框
![image.png](https://img.hacpai.com/file/2019/08/image-b74f5e84.png)

选择修改，即可对分辨率等信息进行修改操作了
![image.png](https://img.hacpai.com/file/2019/08/image-d28e6d5b.png)

