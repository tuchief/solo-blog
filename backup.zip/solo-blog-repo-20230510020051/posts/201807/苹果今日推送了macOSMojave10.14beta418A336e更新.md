title: 苹果今日推送了macOS Mojave 10.14 beta 4（18A336e）更新
date: '2018-07-18 13:06:01'
updated: '2018-07-24 16:37:57'
tags: [macOS Mojave]
permalink: /articles/2018/07/18/1531890338132.html
---
![](http://ouco65qeg.bkt.clouddn.com/2018-07-18-050229.jpg)

# 不要升级，不要升级，不要升级

Apple今天通过Apple开发者门户网站向注册开发商推出了即将推出的macOS Mojave 10.14计算机操作系统的第四个测试版。

在第三次测试版发布后两周，修改后的beta 3版本仅用了六天，修复了使用反馈助手实用程序的崩溃，开发人员可以使用该实用程序向Apple发送反馈，macOS Mojave 10.14 beta 4（18A336e）现在可用于通过所有现有用户的OTA（Over-the-Air）更新进行安装。
![](http://ouco65qeg.bkt.clouddn.com/2018-07-18-15318889794583.jpg)

对下载和安装最新的macOS Mojave 10.14 beta感兴趣的开发人员必须从他们的Apple Developer帐户下载macOS Developer Beta Access Utility。安装后，当Apple在Apple Developer门户网站上发布时，他们会自动收到新的测试版。
![](http://ouco65qeg.bkt.clouddn.com/2018-07-18-15318890305435.jpg)

最有可能的是，Apple仅针对macOS Mojave发布了第四个测试版，因为它希望允许已购买最近发布的MacBook Pro 2018笔记本电脑的开发人员安装其即将推出的操作系统。但是，测试版软件只应安装在专用于macOS应用程序开发的设备上。

macOS Mojave 10.14 beta 4解决了beta 3版本中出现的各种问题，而最大的可見功能改變之一，就是加入新動態桌面 Solar Gradients 選項。動態桌面會按用戶身處的位置及時間而有所改變，例如 Mojave 在之前的 Beta 就提供了 Mojave 沙漠的動態桌面，日間及夜晚的沙漠也有不同。而今次 Solar Gradients 則以太陽的變化作主題，是第 2 款 Mojave 的動態桌面。

但它也引入了新的问题。注册开发人员可以在Apple开发人员帐户的“下载”部分找到详细的更改日志，因此请确保在安装此测试版之前阅读该文档。

目前日常在使用过程中发现存在的几个问题：
1、软件兼容性问题还是会有的，比如ClearnMyMac3没法使用了；
2、TotalFinder会提示需要关闭SIP功能才能使用；
3、有些软件在暗黑模式下显示存在问题，例如：Navicat Premium;
4、系统的流畅程度有所提示，但是依旧和10.13的正式版存在差距；
5、......欢迎回复您所遇到的各种Bug...