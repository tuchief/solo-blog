title: 关于解决TeamViewer商业用途的提示方法
date: '2018-10-23 17:17:37'
updated: '2019-05-10 17:29:00'
tags: [teamviewer, 软件]
permalink: /articles/2018/10/23/1540286152157.html
---
![](https://img.hacpai.com/bing/20181102.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


近期不断有TeamViewer个人用途的用户收到了疑似商业用途的提醒和限制，使用下面的方法可以解除限制

访问下面的地址，用英语填写表单之后提交等待处理即可！
[点我访问](https://www.teamviewer.com/en/support/personal-use-verification/?_ga=2.117268998.1484940703.1528069526-1104778141.1527119212)

处理结束好像不会受到任何提醒

反正我是没收到

但是我的已经解除限制了