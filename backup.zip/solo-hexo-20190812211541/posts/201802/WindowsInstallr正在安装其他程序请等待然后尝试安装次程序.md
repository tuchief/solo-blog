title: Windows Installr 正在安装其他程序。请等待，然后尝试安装次程序
date: '2018-02-23 17:01:54'
updated: '2018-02-23 17:03:44'
tags: [windows]
permalink: /articles/2018/02/23/1519376514293.html
---
### 问题
> Windows Installr 正在安装其他程序。请等待，然后尝试安装次程序

### 解决方式
> ***在任务管理器中强制关闭MSIEXEC.exe***
***或者***
***简单粗暴的方式，重启电脑***