title: 在JetBrains 全家桶中使用正则表达式进行全局替换的简单操作
date: '2017-08-30 23:54:08'
updated: '2017-08-30 23:58:17'
tags: [JetBrains, IntelliJ IDEA, PyCharm, WebStorm, 正则表达式, 工具, 技术]
permalink: /articles/2017/08/30/1504108330525.html
---
##### 废话连篇
>以下纯属废话，请直接跳转正文
JetBrains(以下简称JB)作为一家捷克的私人持股的软件开发公司，第一次认识它是因为JB最为人所熟知的产品 IntelliJ IDEA，作为“全宇宙”最吊炸天的智慧型的Java整合开发工具，让我入坑后就越陷越深，以至于现在只要需要IDE就最先瞧下JB是不是有可以替代的。
现在在电脑上服役的有IDEA、PyCharm、WebStorm、DataGrip,除了IDEA，其它的工具可能并不如你所认知的专业工具好，例如DataGrip这款数据库管理工具，功能全面却不专业（或许我玩的时间还短），针对不同数据库你可以选择更加专业的软件，但我依然使用JB的全家桶，是因为我习惯了他的界面，习惯了它的快捷方式，习惯了它的聪明才智。废话到此结束，开始正文！
JB出品，必属精品！(原谅我没有用过更好的吧！)

##### 正文开始
###### 我的需求是想把整个工程里头的如下字符串匹配出来进行替换：
```
../include/thumb.php?dir=../upload/201707/1500698517.jpg&x=900&y=500
```
要匹配的字符串在整个文档中所处的形态如下所示：

```
<img data-lazy="../include/thumb.php?dir=../upload/201707/1500698517.jpg&x=900&y=500" class="img-responsive" alt="VAT_Varese Theater Competition _ Varese theatre design competition program" />
```
知道了要匹配的内容，现在就是替换了，这是我最终要的结果：

```
../include/thumb.php-dir=../upload-201707-1500698517.jpg&x=900&y=500.jpeg
```
对比前后，你可以发现我需要将字符串中的一些“/”替换成“-”，同时在末尾添加".jpeg"后缀，最终匹配替换成如下形态：

```
<img data-lazy="../include/thumb.php-dir=../upload-201707-1500698517.jpg&x=900&y=500.jpeg" class="img-responsive" alt="VAT_Varese Theater Competition _ Varese theatre design competition program" />
```
那么该如何操作呢？
windows快捷键：**ctrl+shift+r**
mac快捷键：**command+shift+r**
打开如下窗口
![](http://ouco65qeg.bkt.clouddn.com/jb_zzbdspp.png)

**看图能看明白的，后面的内容同样也不用看了，到此结束**
* 需要勾选使用正则表达式选项（**Regex**）
* 作用域选择整个项目进行匹配（**In Project**)
* 在第一个的输入框中填写正则表达式来匹配要匹配的字符串，你需要观察需要被匹配的字符串特征，提取公共特殊，使用通配符来匹配，把需要被替换的字符写出来
* 在第二个输入框中填写替换的字符串，其中**\$1.....$n**指的是你第一个输入框中使用通配符匹配出来的内容，即在替换过程中需要保持不变的，简单点说，就是与正则表达式中的通配符一一对应。其它内容就按替换后的字符串来替换就行了，

##### 结束
