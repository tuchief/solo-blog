title: 'Python&Scrapy异常解决：requests.exceptions.InvalidHeader: Invalid return character
  or leading space in header: Referer'
date: '2019-11-19 10:25:47'
updated: '2019-11-19 10:25:47'
tags: [python, scrapy]
permalink: /articles/2019/11/19/1574130347443.html
---
先说结论，产生这问题的根本原因是因为在写头部信息的时候，不小心在‘Referer’值的开头加入了空格导致的，错误示范如下所示：
```
headers={
    'Host': 'www.baidu.com',
    'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E)',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': ' http://110.120.12.11:1234/',
    ...
}
```
正确的写法应为：
```
headers={
    'Host': 'www.baidu.com',
    'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 10.0; WOW64; Trident/7.0; .NET4.0C; .NET4.0E)',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'Referer': 'http://110.120.12.11:1234/',
    ...
}
```
